import { Component, OnInit, Inject, inject } from '@angular/core';
import { CommonModule, AsyncPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonHeader, IonToolbar, IonTitle, IonButtons, IonButton, IonContent, IonList, IonItem, IonLabel, IonIcon, IonFab, IonFabButton } from '@ionic/angular/standalone';
import { RouterLink } from '@angular/router';
import { addIcons } from 'ionicons';
import { add, megaphoneOutline } from 'ionicons/icons';
import { CriancaService } from '../../core/services/crianca.service';

@Component({
 selector: 'app-minhas-criancas',
 templateUrl: './minhas-criancas.page.html',
 styleUrls: ['./minhas-criancas.page.scss'],
 standalone: true,
 imports: [IonHeader,IonButton, IonButtons, IonToolbar, IonTitle, IonContent, IonList, IonItem, IonLabel, IonIcon, IonFab, IonFabButton, AsyncPipe, RouterLink]
})
export class MinhasCriancasPage {
 private criacaService = inject(CriancaService);
 criancas$ = this.criacaService.listar();

 constructor() {
  addIcons({ add, megaphoneOutline }); 
 }
}
